olcoop - Overload campaign co-op (up to 3 players)
==================================================

What you need
  - Overload on Steam, and Steam running.
  - olmod 0.5.14 installed in your Overload folder (https://olmod.overloadmaps.com).
  - Host and every player must run the SAME olcoop version (shown top-left on the main menu).

Install
  1. Unzip this folder anywhere.
  2. Run install.bat (it finds your Overload folder or asks for it, copies the mod and checks the copy).

Play
  1. Start the game with olcoop.bat (in your Overload folder). Do not start it from Steam's Play button:
     that runs the game without olmod.
  2. Main menu, bottom right: CO-OP: HOST / JOIN.
     Host:   HOST A CO-OP GAME, invite your friends from the list, then BACK and start or continue the campaign
             (PLAY MISSION / LOAD SAVED GAME) as usual.
     Friend: accept the host's Steam invite (game already running), or open CO-OP and pick the friend who is hosting.
             You are taken into the host's level automatically.
  No port forwarding is needed: the connection goes through Steam.

Between levels
  Everyone sees the results and upgrade screens. Joiners press READY UP; the host's next level starts when
  everybody is ready.

Logs (for bug reports): Overload\olcoop_logs
Uninstall: run uninstall.bat (olmod and the game are not touched).
